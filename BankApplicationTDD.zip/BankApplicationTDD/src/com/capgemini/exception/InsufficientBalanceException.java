package com.capgemini.exception;

public abstract class InsufficientBalanceException extends Exception {

}
