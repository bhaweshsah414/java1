package com.capgemini.exception;

public class InsufficientInitialAmountException extends Exception {

}
